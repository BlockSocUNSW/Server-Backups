package mffs;

import net.minecraft.server.ItemBlock;
import net.minecraft.server.ItemStack;

public class ItemMachines extends ItemBlock
{
    public ItemMachines(int var1)
    {
        super(var1);
        this.setMaxDurability(0);
        this.a(true);
    }

    /**
     * Returns the metadata of the block which this Item (ItemBlock) can place
     */
    public int filterData(int var1)
    {
        return this.getPlacedBlockMetadata(var1);
    }

    public int getPlacedBlockMetadata(int var1)
    {
        return var1;
    }

    public String a(ItemStack var1)
    {
        int var2 = var1.getData();

        switch (var2)
        {
            case 0:
                return "Generator_Core";

            case 1:
                return "Area_Projektor";

            case 2:
                return "Directional_Projektor";

            case 3:
                return "Deflector_Projektor";

            case 4:
                return "Tube_Projektor";

            case 5:
                return "Directional_Extender";

            case 6:
                return "Generator_EU_Injektor";

            case 7:
                return "Reaktor_Field";

            case 8:
                return "Reaktor_Cooler";

            case 9:
                return "Reaktor_Monitor";

            default:
                return null;
        }
    }
}
