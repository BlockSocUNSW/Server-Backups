package mffs;

import net.minecraft.server.EntityHuman;
import net.minecraft.server.IInventory;
import net.minecraft.server.ItemStack;
import net.minecraft.server.NBTTagCompound;
import net.minecraft.server.NBTTagList;
import net.minecraft.server.TileEntity;
import net.minecraft.server.World;

public class TileEntityReaktorMonitorClient extends TileEntityMaschines implements IInventory
{
    private boolean[] channel = new boolean[] {false, false, false, false, false, false};
    private ItemStack[] ItemStacks = new ItemStack[1];
    private int linkMonitor_ID = 0;
    private boolean linkMonitor = false;
    private int usechannel = 0;
    private static int maxchannel = 5;
    private String Montorname = null;
    private boolean Signal = false;
    private int conectet_ID;

    public int[] getUpdate()
    {
        return new int[] {this.usechannel, this.linkMonitor_ID, this.linkMonitor ? 1 : 0};
    }

    public void handleUpdate(int[] var1)
    {
        this.usechannel = var1[0];
        this.linkMonitor_ID = var1[1];
        this.linkMonitor = (var1[2] & 1) != 0;
        this.Montorname = "Monitor@" + this.linkMonitor_ID;
    }

    public void handleButton(int var1)
    {
        if (var1 >= 0 && var1 <= 4 && this.getUsechannel() != var1)
        {
            this.setUsechannel(var1);
        }
    }

    public void addfreqcard()
    {
        if (this.getItem(0) != null)
        {
            if (this.getItem(0).getItem() == mod_ModularForceFieldSystem.MFFSitemsclc && this.linkMonitor_ID != Functions.getTAGfromItemstack(this.getItem(0)).getInt("RMonitorID"))
            {
                this.linkMonitor_ID = Functions.getTAGfromItemstack(this.getItem(0)).getInt("RMonitorID");
            }
        }
        else
        {
            this.linkMonitor_ID = 0;
        }
    }

    public void updatecheck()
    {
        if (!this.world.isStatic && this.isLinkMonitor())
        {
            TileEntity var1 = (TileEntity)Linkgrid.getWorldMap(this.world).getRMonitor().get(Integer.valueOf(this.getLinkMonitor_ID()));

            if (var1 == null)
            {
                this.setConectet_ID(0);
                this.setActive(false);
                this.q_();
            }
        }
    }

    /**
     * Allows the entity to update its state. Overridden in most subclasses, e.g. the mob spawner uses this to count
     * ticks and creates a new spawn inside its implementation.
     */
    public void q_()
    {
        if (!this.world.isStatic)
        {
            this.addfreqcard();

            if (this.getLinkMonitor_ID() != 0)
            {
                this.setLinkMonitor(true);

                try
                {
                    this.channel = ((TileEntityReaktorMonitor)Linkgrid.getWorldMap(this.world).getRMonitor().get(Integer.valueOf(this.getLinkMonitor_ID()))).getChannel();
                    this.Montorname = ((TileEntityReaktorMonitor)Linkgrid.getWorldMap(this.world).getRMonitor().get(Integer.valueOf(this.getLinkMonitor_ID()))).getMontorname();
                    this.setConectet_ID(this.getLinkMonitor_ID());
                }
                catch (NullPointerException var2)
                {
                    this.setLinkMonitor(false);
                    this.setLinkMonitor_ID(0);
                    this.setMontorname("null");
                    this.setConectet_ID(0);
                }
            }
            else
            {
                this.setLinkMonitor(false);
                this.setConectet_ID(0);
                this.setMontorname("null");
            }

            if (this.isLinkMonitor())
            {
                if (this.channel[this.usechannel])
                {
                    if (!this.isSignal())
                    {
                        this.setSignal(true);
                        this.world.k(this.x, this.y, this.z);
                        notifyNeighbors(this.world, this.x, this.y, this.z);
                    }
                }
                else if (this.isSignal())
                {
                    this.setSignal(false);
                    this.world.k(this.x, this.y, this.z);
                    notifyNeighbors(this.world, this.x, this.y, this.z);
                }
            }
        }
    }

    public static void notifyNeighbors(World var0, int var1, int var2, int var3)
    {
        for (int var4 = 0; var4 < 6; ++var4)
        {
            var0.applyPhysics(var1, var2, var3, var4);
            var0.applyPhysics(var1 - 1, var2, var3, var4);
            var0.applyPhysics(var1 + 1, var2, var3, var4);
            var0.applyPhysics(var1, var2 - 1, var3, var4);
            var0.applyPhysics(var1, var2 + 1, var3, var4);
            var0.applyPhysics(var1, var2, var3 - 1, var4);
            var0.applyPhysics(var1, var2, var3 + 1, var4);
        }
    }

    /**
     * Reads a tile entity from NBT.
     */
    public void a(NBTTagCompound var1)
    {
        super.a(var1);
        this.usechannel = var1.getInt("usechannel");
        NBTTagList var2 = var1.getList("Items");
        this.ItemStacks = new ItemStack[this.getSize()];

        for (int var3 = 0; var3 < var2.size(); ++var3)
        {
            NBTTagCompound var4 = (NBTTagCompound)var2.get(var3);
            byte var5 = var4.getByte("Slot");

            if (var5 >= 0 && var5 < this.ItemStacks.length)
            {
                this.ItemStacks[var5] = ItemStack.a(var4);
            }
        }
    }

    /**
     * Writes a tile entity to NBT.
     */
    public void b(NBTTagCompound var1)
    {
        super.b(var1);
        var1.setInt("usechannel", this.usechannel);
        NBTTagList var2 = new NBTTagList();

        for (int var3 = 0; var3 < this.ItemStacks.length; ++var3)
        {
            if (this.ItemStacks[var3] != null)
            {
                NBTTagCompound var4 = new NBTTagCompound();
                var4.setByte("Slot", (byte)var3);
                this.ItemStacks[var3].save(var4);
                var2.add(var4);
            }
        }

        var1.set("Items", var2);
    }

    /**
     * Decrease the size of the stack in slot (first int arg) by the amount of the second int arg. Returns the new
     * stack.
     */
    public ItemStack splitStack(int var1, int var2)
    {
        if (this.ItemStacks[var1] != null)
        {
            ItemStack var3;

            if (this.ItemStacks[var1].count <= var2)
            {
                var3 = this.ItemStacks[var1];
                this.ItemStacks[var1] = null;
                return var3;
            }
            else
            {
                var3 = this.ItemStacks[var1].a(var2);

                if (this.ItemStacks[var1].count == 0)
                {
                    this.ItemStacks[var1] = null;
                }

                return var3;
            }
        }
        else
        {
            return null;
        }
    }

    /**
     * Sets the given item stack to the specified slot in the inventory (can be crafting or armor sections).
     */
    public void setItem(int var1, ItemStack var2)
    {
        this.ItemStacks[var1] = var2;

        if (var2 != null && var2.count > this.getMaxStackSize())
        {
            var2.count = this.getMaxStackSize();
        }
    }

    public boolean canInteractWith(EntityHuman var1)
    {
        return this.world.getTileEntity(this.x, this.y, this.z) != this ? false : var1.e((double)this.x + 0.5D, (double)this.y + 0.5D, (double)this.z + 0.5D) <= 64.0D;
    }

    /**
     * Returns the stack in slot i
     */
    public ItemStack getItem(int var1)
    {
        return this.ItemStacks[var1];
    }

    /**
     * Returns the name of the inventory.
     */
    public String getName()
    {
        return "Camoflageupgrade";
    }

    /**
     * Returns the maximum stack size for a inventory slot. Seems to always be 64, possibly will be extended. *Isn't
     * this more of a set than a get?*
     */
    public int getMaxStackSize()
    {
        return 1;
    }

    /**
     * Returns the number of slots in the inventory.
     */
    public int getSize()
    {
        return this.ItemStacks.length;
    }

    /**
     * Do not make give this method the name canInteractWith because it clashes with Container
     */
    public boolean a(EntityHuman var1)
    {
        return this.world.getTileEntity(this.x, this.y, this.z) != this ? false : var1.f((double)this.x + 0.5D, (double)this.y + 0.5D, (double)this.z + 0.5D) <= 64.0D;
    }

    public void f() {}

    public void g() {}

    public int getLinkMonitor_ID()
    {
        return this.linkMonitor_ID;
    }

    public void setLinkMonitor_ID(int var1)
    {
        this.linkMonitor_ID = var1;
        ++this.updateCount;
    }

    public boolean isLinkMonitor()
    {
        return this.linkMonitor;
    }

    public void setLinkMonitor(boolean var1)
    {
        if (var1 != this.linkMonitor)
        {
            ++this.updateCount;
        }

        this.linkMonitor = var1;
    }

    public int getUsechannel()
    {
        return this.usechannel;
    }

    public void setUsechannel(int var1)
    {
        this.usechannel = var1;
        ++this.updateCount;
    }

    public String getMontorname()
    {
        return this.Montorname;
    }

    public void setMontorname(String var1)
    {
        this.Montorname = var1;
    }

    public boolean getChannel()
    {
        return this.channel[this.getUsechannel()];
    }

    public boolean isSignal()
    {
        return this.Signal;
    }

    public void setSignal(boolean var1)
    {
        this.Signal = var1;
    }

    public int getConectet_ID()
    {
        return this.conectet_ID;
    }

    public void setConectet_ID(int var1)
    {
        this.conectet_ID = var1;
    }

    /**
     * When some containers are closed they call this on each slot, then drop whatever it returns as an EntityItem -
     * like when you close a workbench GUI.
     */
    public ItemStack splitWithoutUpdate(int var1)
    {
        return null;
    }
}
