package mffs;

import net.minecraft.server.NBTTagCompound;
import net.minecraft.server.NetworkManager;
import net.minecraft.server.Packet;
import net.minecraft.server.Packet132TileEntityData;
import net.minecraft.server.TileEntity;

public class TileCamouflagedField extends TileEntity
{
    public int camoBlockId = -1;

    /**
     * Overriden in a sign to provide the text
     */
    public Packet d()
    {
        Packet132TileEntityData var1 = new Packet132TileEntityData();
        var1.lowPriority = true;
        var1.a = this.x;
        var1.b = this.y;
        var1.c = this.z;
        var1.d = 0;
        var1.e = this.camoBlockId;
        var1.f = 0;
        var1.g = 0;
        return var1;
    }

    public void onDataPacket(NetworkManager var1, Packet132TileEntityData var2)
    {
        this.camoBlockId = var2.e;
    }

    /**
     * Writes a tile entity to NBT.
     */
    public void b(NBTTagCompound var1)
    {
        super.b(var1);
        var1.setInt("camo", this.camoBlockId);
    }

    /**
     * Reads a tile entity from NBT.
     */
    public void a(NBTTagCompound var1)
    {
        super.a(var1);
        this.camoBlockId = var1.getInt("camo");
    }
}
