package mffs;

import cpw.mods.fml.common.FMLCommonHandler;
import immibis.core.NonSharedProxy;
import java.io.File;
import java.util.logging.Logger;
import net.minecraft.server.EntityHuman;
import net.minecraft.server.ItemStack;
import net.minecraft.server.NBTTagCompound;

public class Functions
{
    private static final Logger log = Logger.getLogger("Client");

    public static void DisplayInfo(String var0)
    {
        log.info(var0);
    }

    public static File getMinecraftDir()
    {
        return FMLCommonHandler.instance().getMinecraftRootDirectory();
    }

    public static int getBlockIdFor(String var0, int var1)
    {
        if (mod_ModularForceFieldSystem.config == null)
        {
            return var1;
        }
        else
        {
            try
            {
                return (new Integer(mod_ModularForceFieldSystem.config.getOrCreateIntProperty(var0, "1", var1).value)).intValue();
            }
            catch (Exception var3)
            {
                System.out.println("[ModularForceFieldSystem] Error while trying to access ID-List, config wasn\'t loaded properly!");
                return var1;
            }
        }
    }

    public static int getItemIdFor(String var0, int var1)
    {
        if (mod_ModularForceFieldSystem.config == null)
        {
            return var1;
        }
        else
        {
            try
            {
                return (new Integer(mod_ModularForceFieldSystem.config.getOrCreateIntProperty(var0, "2", var1).value)).intValue();
            }
            catch (Exception var3)
            {
                System.out.println("[ModularForceFieldSystem] Error while trying to access ID-List, config wasn\'t loaded properly!");
                return var1;
            }
        }
    }

    public static void ChattoPlayer(EntityHuman var0, String var1)
    {
        NonSharedProxy.sendChat(var0, var1);
    }

    public static NBTTagCompound getTAGfromItemstack(ItemStack var0)
    {
        NBTTagCompound var1 = var0.getTag();

        if (var1 == null)
        {
            var1 = new NBTTagCompound();
            var0.setTag(var1);
        }

        return var1;
    }
}
