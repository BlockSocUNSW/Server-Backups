package mffs;

import forge.ITextureProvider;
import net.minecraft.server.EntityHuman;
import net.minecraft.server.Item;
import net.minecraft.server.ItemStack;
import net.minecraft.server.World;

public class ItemSecLinkCard extends Item implements ITextureProvider
{
    private StringBuffer info = new StringBuffer();

    public ItemSecLinkCard(int var1)
    {
        super(var1);
        this.d(19);
        this.e(1);
    }

    public String getTextureFile()
    {
        return "/mffs_grafik/items.png";
    }

    public boolean isRepairable()
    {
        return false;
    }

    /**
     * Called whenever this item is equipped and the right mouse button is pressed. Args: itemStack, world, entityPlayer
     */
    public ItemStack a(ItemStack var1, World var2, EntityHuman var3)
    {
        if (Functions.getTAGfromItemstack(var1).hasKey("RMonitorID"))
        {
            this.info.setLength(0);
            this.info.append("Link Card ID: ").append(String.valueOf(Functions.getTAGfromItemstack(var1).getInt("RMonitorID")));
        }
        else
        {
            this.info.setLength(0);
            this.info.append("Link Card ID: is empty ");
        }

        Functions.ChattoPlayer(var3, this.info.toString());
        return var1;
    }
}
