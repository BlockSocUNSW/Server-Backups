package mffs;

import java.util.LinkedList;
import java.util.NoSuchElementException;

public class ForceFieldWorldMap
{
    private boolean sync;
    private int x;
    private int y;
    private int z;
    private LinkedList ffworld = new LinkedList();

    public ForceFieldWorldMap(int var1, int var2, int var3)
    {
        this.x = var1;
        this.y = var2;
        this.z = var3;
        this.sync = true;
    }

    public boolean getsync()
    {
        return this.sync;
    }

    public void setsync(boolean var1)
    {
        this.sync = var1;
    }

    public void ffworld_setfistactive(boolean var1)
    {
        ((ForceFieldBlock)this.ffworld.getFirst()).setActive(var1);
    }

    public boolean ffworld_getfistactive()
    {
        return ((ForceFieldBlock)this.ffworld.getFirst()).isActive();
    }

    public short ffworld_getfistmode()
    {
        return ((ForceFieldBlock)this.ffworld.getFirst()).getMode();
    }

    public void ffworld_setfirstfreeospace(boolean var1)
    {
        ((ForceFieldBlock)this.ffworld.getFirst()).setFreespace(var1);
    }

    public boolean ffworld_getfirstfreespace()
    {
        return ((ForceFieldBlock)this.ffworld.getFirst()).isFreespace();
    }

    public int ffworld_getfirstGenerator_ID()
    {
        return ((ForceFieldBlock)this.ffworld.getFirst()).getGenerator_Id();
    }

    public int ffworld_getfirstProjektor_ID()
    {
        try
        {
            return ((ForceFieldBlock)this.ffworld.getFirst()).getProjektor_ID();
        }
        catch (NoSuchElementException var2)
        {
            return 0;
        }
    }

    public void ffworld_addFirst(ForceFieldBlock var1)
    {
        this.ffworld.addFirst(var1);
    }

    public void ffworld_addLast(ForceFieldBlock var1)
    {
        this.ffworld.addLast(var1);
    }

    public ForceFieldBlock ffworld_getfirst()
    {
        return (ForceFieldBlock)this.ffworld.getFirst();
    }

    public ForceFieldBlock ffworld_getLast()
    {
        return (ForceFieldBlock)this.ffworld.getLast();
    }

    public void ffworld_removefirst()
    {
        this.ffworld.removeFirst();
    }

    public void ffworld_remove(int var1)
    {
        for (int var2 = 0; var2 < this.ffworld.size(); ++var2)
        {
            ForceFieldBlock var3 = (ForceFieldBlock)this.ffworld.get(var2);

            if (var3.getProjektor_ID() == var1)
            {
                this.ffworld.remove(var2);
            }
        }
    }

    public int listsize()
    {
        return this.ffworld.size();
    }

    public int getX()
    {
        return this.x;
    }

    public int getY()
    {
        return this.y;
    }

    public int getZ()
    {
        return this.z;
    }
}
