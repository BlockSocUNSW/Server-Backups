package mffs;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public final class TexturworldMap_Unused
{
    private static Map Textur_Map = new HashMap();
    private static StringBuffer hasher = new StringBuffer();

    public static TexturworldMap_Unused.TexturMap getTexturMap(Integer var0)
    {
        if (!Textur_Map.containsKey(var0))
        {
            Textur_Map.put(var0, new TexturworldMap_Unused.TexturMap());
        }

        return (TexturworldMap_Unused.TexturMap)Textur_Map.get(var0);
    }

    static class TexturMap
    {
        public static Map TTextur = new Hashtable();

        public void add(int var1, int var2, int var3, int var4)
        {
            TexturworldMap_Unused.hasher.setLength(0);
            TexturworldMap_Unused.hasher.append(var1).append("/").append(var2).append("/").append(var3);
            TTextur.put(TexturworldMap_Unused.hasher.toString(), Integer.valueOf(var4));
        }

        public void addfromUpate(String var1, int var2)
        {
            TTextur.put(var1.toString(), Integer.valueOf(var2));
        }

        public int getTextur(int var1, int var2, int var3)
        {
            TexturworldMap_Unused.hasher.setLength(0);
            TexturworldMap_Unused.hasher.append(var1).append("/").append(var2).append("/").append(var3);
            return TTextur.get(TexturworldMap_Unused.hasher.toString()) != null ? ((Integer)TTextur.get(TexturworldMap_Unused.hasher.toString())).intValue() : -1;
        }

        public int getSize()
        {
            return TTextur.size();
        }
    }
}
