package mffs;

import forge.ITextureProvider;
import net.minecraft.server.Item;

public class ItemCardempty extends Item implements ITextureProvider
{
    public ItemCardempty(int var1)
    {
        super(var1);
        this.d(16);
        this.e(1);
    }

    public String getTextureFile()
    {
        return "/mffs_grafik/items.png";
    }

    public boolean isRepairable()
    {
        return false;
    }
}
