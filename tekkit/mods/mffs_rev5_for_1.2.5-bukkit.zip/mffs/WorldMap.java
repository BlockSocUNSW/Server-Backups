package mffs;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import net.minecraft.server.World;

public final class WorldMap
{
    private static Map ForceFieldWorld = new HashMap();
    private static StringBuffer hasher = new StringBuffer();

    public static WorldMap.WorldForceField getForceFieldforWorld(World var0)
    {
        if (var0 != null)
        {
            if (!ForceFieldWorld.containsKey(var0))
            {
                ForceFieldWorld.put(var0, new WorldMap.WorldForceField());
            }

            return (WorldMap.WorldForceField)ForceFieldWorld.get(var0);
        }
        else
        {
            return null;
        }
    }

    static class WorldForceField
    {
        private static Map FFWorldMap = new Hashtable();

        public ForceFieldWorldMap addandgetffmp(int var1, int var2, int var3)
        {
            WorldMap.hasher.setLength(0);
            WorldMap.hasher.append(var1).append("/").append(var2).append("/").append(var3);

            if (FFWorldMap.get(WorldMap.hasher.toString()) == null)
            {
                FFWorldMap.put(WorldMap.hasher.toString(), new ForceFieldWorldMap(var1, var2, var3));
            }

            return (ForceFieldWorldMap)FFWorldMap.get(WorldMap.hasher.toString());
        }

        public ForceFieldWorldMap getffmp(int var1, int var2, int var3)
        {
            WorldMap.hasher.setLength(0);
            WorldMap.hasher.append(var1).append("/").append(var2).append("/").append(var3);
            return (ForceFieldWorldMap)FFWorldMap.get(WorldMap.hasher.toString());
        }

        public ForceFieldWorldMap getFFWM(String var1)
        {
            return (ForceFieldWorldMap)FFWorldMap.get(var1);
        }
    }
}
