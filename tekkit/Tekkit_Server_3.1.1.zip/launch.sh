#!/bin/sh
java -Xmx768M -Xms512M -jar Tekkit.jar nogui
