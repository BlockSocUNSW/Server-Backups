package mffs.packet;

import immibis.core.NonSharedProxy;
import immibis.core.net.AbstractContainerSyncPacket;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import net.minecraft.server.EntityHuman;

public class PacketGenericUpdate extends AbstractContainerSyncPacket
{
    public int[] data;
    public int[] baseData;

    public void onReceived(EntityHuman var1)
    {
        if (!NonSharedProxy.SERVER)
        {
            super.onReceived(var1);
        }
    }

    public void write(DataOutputStream var1) throws IOException
    {
        int var2;

        if (this.data == null)
        {
            var1.writeInt(0);
        }
        else
        {
            var1.writeInt(this.data.length);

            for (var2 = 0; var2 < this.data.length; ++var2)
            {
                var1.writeInt(this.data[var2]);
            }
        }

        if (this.baseData == null)
        {
            var1.writeInt(0);
        }
        else
        {
            var1.writeInt(this.baseData.length);

            for (var2 = 0; var2 < this.baseData.length; ++var2)
            {
                var1.writeInt(this.baseData[var2]);
            }
        }
    }

    public void read(DataInputStream var1) throws IOException
    {
        this.data = new int[var1.readInt()];
        int var2;

        for (var2 = 0; var2 < this.data.length; ++var2)
        {
            this.data[var2] = var1.readInt();
        }

        this.baseData = new int[var1.readInt()];

        for (var2 = 0; var2 < this.baseData.length; ++var2)
        {
            this.baseData[var2] = var1.readInt();
        }
    }

    public byte getID()
    {
        return (byte)0;
    }
}
