package mffs;

import net.minecraft.server.EntityHuman;
import net.minecraft.server.ItemStack;
import net.minecraft.server.Slot;

public class ContainerReaktorMonitorClient extends ContainerMFFS
{
    private TileEntityReaktorMonitorClient ReaktorMonitorClient;

    public ContainerReaktorMonitorClient(EntityHuman var1, TileEntityReaktorMonitorClient var2)
    {
        super(var1, var2);
        this.ReaktorMonitorClient = var2;
        this.a(new Slot(this.ReaktorMonitorClient, 0, 97, 120));

        for (int var3 = 0; var3 < 9; ++var3)
        {
            this.a(new Slot(var1.inventory, var3, 8 + var3 * 18, 142));
        }
    }

    /**
     * Callback for when the crafting gui is closed.
     */
    public void a(EntityHuman var1)
    {
        super.a(var1);
        var1.defaultContainer.a();
    }

    /**
     * Called to transfer a stack from one inventory to the other eg. when shift clicking.
     */
    public ItemStack a(int var1)
    {
        ItemStack var2 = null;
        Slot var3 = (Slot)this.e.get(var1);

        if (var3 != null && var3.c())
        {
            ItemStack var4 = var3.getItem();
            var2 = var4.cloneItemStack();

            if (var4.count == 0)
            {
                var3.set((ItemStack)null);
            }
            else
            {
                var3.d();
            }

            if (var4.count == var2.count)
            {
                return null;
            }

            var3.c(var4);
        }

        return var2;
    }
}
